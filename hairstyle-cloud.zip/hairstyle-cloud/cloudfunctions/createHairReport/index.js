const cloud = require('wx-server-sdk');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();

/**
 * 创建发型报告，并根据每日免费次数判断是否需要分享解锁。
 * 输入参数：
 *   fileId: 上传到云存储的图片 fileID。
 */
exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext();
  const { fileId } = event;
  const dateStr = new Date().toISOString().substring(0, 10);
  const usageLogs = db.collection('usage_logs');

  // 获取今天的使用记录
  let usageRes = await usageLogs.where({ openid: OPENID, date: dateStr }).get();
  let usage;
  if (usageRes.data.length === 0) {
    usage = { openid: OPENID, date: dateStr, count: 0, tokens: 0 };
    const addRes = await usageLogs.add({ data: usage });
    usage._id = addRes._id;
  } else {
    usage = usageRes.data[0];
  }

  let requiresUnlock = false;
  // 当天已生成超过 1 次，需要消耗 token 或锁定
  if (usage.count >= 1) {
    if (usage.tokens && usage.tokens > 0) {
      // 消耗一次 token
      usage.tokens -= 1;
      await usageLogs.doc(usage._id).update({ data: { tokens: usage.tokens } });
    } else {
      requiresUnlock = true;
    }
  } else {
    // 首次生成
    usage.count += 1;
    await usageLogs.doc(usage._id).update({ data: { count: usage.count } });
  }

  // 创建报告
  const reports = db.collection('hair_reports');
  const reportData = {
    openid: OPENID,
    imageFileId: fileId,
    status: requiresUnlock ? 'locked' : 'completed', // 模拟立即完成
    requiresUnlock: requiresUnlock,
    posterWatermarkedUrl: requiresUnlock ? null : 'https://via.placeholder.com/750x1000?text=Poster',
    posterCleanUrl: requiresUnlock ? null : 'https://via.placeholder.com/750x1000?text=Poster+HD',
    createdAt: new Date(),
  };
  const reportRes = await reports.add({ data: reportData });
  return {
    reportId: reportRes._id,
    requiresUnlock: requiresUnlock
  };
};