const cloud = require('wx-server-sdk');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();

/**
 * 分享解锁函数。调用此函数给当前用户增加一次使用次数或解锁特定报告。
 * 输入参数：
 *   reportId: 需要解锁的报告 ID
 */
exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext();
  const { reportId } = event;
  const dateStr = new Date().toISOString().substring(0, 10);

  // 给用户增加一个 token
  const usageRes = await db.collection('usage_logs').where({ openid: OPENID, date: dateStr }).get();
  if (usageRes.data.length > 0) {
    const usage = usageRes.data[0];
    const newTokens = (usage.tokens || 0) + 1;
    await db.collection('usage_logs').doc(usage._id).update({ data: { tokens: newTokens } });
  } else {
    await db.collection('usage_logs').add({ data: { openid: OPENID, date: dateStr, count: 0, tokens: 1 } });
  }

  // 更新报告解锁状态
  if (reportId) {
    await db.collection('hair_reports').doc(reportId).update({ data: { requiresUnlock: false, status: 'completed', posterWatermarkedUrl: 'https://via.placeholder.com/750x1000?text=Poster', posterCleanUrl: 'https://via.placeholder.com/750x1000?text=Poster+HD' } });
  }

  return {
    success: true
  };
};