const cloud = require('wx-server-sdk');

// 初始化云环境
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();

/**
 * 登录云函数，返回用户信息。
 * 如果数据库中不存在该用户则创建记录（含可用次数 tokens）。
 */
exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext();
  const users = db.collection('users');
  // 查找用户
  const res = await users.where({ openid: OPENID }).get();
  let user;
  if (res.data.length > 0) {
    user = res.data[0];
  } else {
    user = {
      openid: OPENID,
      tokens: 0,
      createdAt: new Date()
    };
    const addRes = await users.add({ data: user });
    user._id = addRes._id;
  }
  return { user };
};