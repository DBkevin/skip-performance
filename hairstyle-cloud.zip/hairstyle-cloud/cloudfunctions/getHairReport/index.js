const cloud = require('wx-server-sdk');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();

/**
 * 查询报告详情函数。
 * 输入参数：
 *   reportId: 报告 ID
 */
exports.main = async (event, context) => {
  const { reportId } = event;
  const res = await db.collection('hair_reports').doc(reportId).get();
  return {
    report: res.data
  };
};