# AI发型分析小程序（微信云开发版）

本示例使用微信云开发（Cloudbase）实现“AI发型分析推荐小程序”的最小可行产品（MVP）。小程序端使用云函数调用后端逻辑，并通过云数据库记录用户每日使用次数、发型报告和分享解锁信息。用户每天可以免费生成一次分析，之后再次生成时默认仅提供带水印版，通过分享/邀请好友可增加额外次数或解锁高清无水印版。

## 目录结构

```
hairstyle-cloud/
├── cloudfunctions/             # 云函数
│   ├── login/                 # 登录函数，返回用户信息
│   │   ├── index.js
│   │   └── package.json
│   ├── createHairReport/      # 创建发型报告并判断免费次数
│   │   ├── index.js
│   │   └── package.json
│   ├── shareUnlock/           # 分享解锁或增加一次次数
│   │   ├── index.js
│   │   └── package.json
│   └── getHairReport/         # 查询报告详情
│       ├── index.js
│       └── package.json
├── miniprogram/               # 小程序前端
│   ├── app.js
│   ├── app.json
│   ├── app.wxss
│   ├── pages/
│   │   ├── index/
│   │   │   ├── index.js
│   │   │   ├── index.json
│   │   │   ├── index.wxml
│   │   │   └── index.wxss
│   │   ├── upload/
│   │   │   ├── upload.js
│   │   │   ├── upload.json
│   │   │   ├── upload.wxml
│   │   │   └── upload.wxss
│   │   ├── wait/
│   │   │   ├── wait.js
│   │   │   ├── wait.json
│   │   │   ├── wait.wxml
│   │   │   └── wait.wxss
│   │   ├── result/
│   │   │   ├── result.js
│   │   │   ├── result.json
│   │   │   ├── result.wxml
│   │   │   └── result.wxss
│   │   └── my/
│   │       ├── my.js
│   │       ├── my.json
│   │       ├── my.wxml
│   │       └── my.wxss
│   └── utils/
│       └── api.js            # 可选封装
└── project.config.json        # 微信开发者工具配置
```

## 快速开始

1. **初始化云开发**：在微信开发者工具中新建云开发环境，开启云函数、云数据库和云存储。
2. **部署云函数**：在 `cloudfunctions` 目录内右键分别选择“部署：云端安装依赖并上传函数代码”。
3. **初始化小程序端**：在 `miniprogram` 下运行并修改 `app.js` 中的环境 ID (`envId`) 和 `app.json` 中的页面路径等配置。
4. **使用指南**：用户每天可以免费生成一份报告；当当日已生成过一份报告时，再次生成时报告将锁定高分辨率版本。完成分享（邀请好友并完成发型测试）后，将为用户增加一次可用次数或直接解锁报告。
