// pages/my/my.js
const app = getApp();

Page({
  data: {
    reports: []
  },
  onShow() {
    this.fetchReports();
  },
  fetchReports() {
    const openid = app.globalData.user ? app.globalData.user.openid : null;
    if (!openid) {
      return;
    }
    wx.cloud.database().collection('hair_reports').where({ openid: openid }).orderBy('createdAt', 'desc').get().then(res => {
      this.setData({ reports: res.data });
    });
  }
});