// pages/result/result.js
Page({
  data: {
    id: '',
    report: null
  },
  onLoad(options) {
    this.setData({ id: options.id });
    this.fetchReport();
  },
  fetchReport() {
    wx.cloud.callFunction({
      name: 'getHairReport',
      data: { reportId: this.data.id }
    }).then(res => {
      this.setData({ report: res.result.report });
    });
  },
  savePoster() {
    const url = this.data.report.posterWatermarkedUrl;
    if (!url) {
      wx.showToast({ title: '暂无可保存图片', icon: 'none' });
      return;
    }
    wx.downloadFile({
      url: url,
      success: (res) => {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success: () => {
            wx.showToast({ title: '已保存', icon: 'success' });
          }
        });
      }
    });
  },
  unlockPoster() {
    wx.cloud.callFunction({
      name: 'shareUnlock',
      data: { reportId: this.data.id }
    }).then(() => {
      this.fetchReport();
    });
  },
  onShareAppMessage() {
    return {
      title: 'AI发型分析报告',
      path: '/pages/index/index'
    };
  }
});