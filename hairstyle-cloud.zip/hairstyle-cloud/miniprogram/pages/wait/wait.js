// pages/wait/wait.js
Page({
  data: {
    id: '',
    status: ''
  },
  onLoad(options) {
    this.setData({ id: options.id });
    this.pollStatus();
  },
  pollStatus() {
    const id = this.data.id;
    wx.cloud.callFunction({
      name: 'getHairReport',
      data: { reportId: id }
    }).then(res => {
      const report = res.result.report;
      this.setData({ status: report.status });
      if (report.status === 'completed' || report.status === 'locked') {
        wx.redirectTo({ url: '/pages/result/result?id=' + id });
      } else {
        setTimeout(() => { this.pollStatus(); }, 3000);
      }
    }).catch(() => {
      setTimeout(() => { this.pollStatus(); }, 3000);
    });
  }
});