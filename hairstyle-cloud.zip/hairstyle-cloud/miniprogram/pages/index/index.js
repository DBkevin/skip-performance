// pages/index/index.js
Page({
  startTest() {
    wx.navigateTo({
      url: '/pages/upload/upload'
    });
  }
});