// pages/upload/upload.js
Page({
  data: {
    image: ''
  },
  chooseImage() {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        this.setData({ image: res.tempFilePaths[0] });
      }
    });
  },
  startAnalysis() {
    const filePath = this.data.image;
    if (!filePath) {
      wx.showToast({ title: '请先选择照片', icon: 'none' });
      return;
    }
    const fileName = Date.now() + '-' + filePath.split('/').pop();
    wx.showLoading({ title: '上传中...' });
    wx.cloud.uploadFile({
      cloudPath: 'reports/' + fileName,
      filePath: filePath,
    }).then(res => {
      wx.hideLoading();
      // 调用云函数创建报告
      return wx.cloud.callFunction({
        name: 'createHairReport',
        data: { fileId: res.fileID }
      });
    }).then(res => {
      const { reportId } = res.result;
      wx.redirectTo({ url: '/pages/wait/wait?id=' + reportId });
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '上传失败', icon: 'none' });
      console.error(err);
    });
  }
});