// 初始化云环境
wx.cloud.init({
  env: '', // 替换为你的云开发环境 ID，如 'prod-xxxxx'
  traceUser: true
});

App({
  globalData: {
    user: null
  },
  onLaunch() {
    // 调用云函数登录并获取用户信息
    wx.cloud.callFunction({
      name: 'login'
    }).then(res => {
      this.globalData.user = res.result.user;
    }).catch(err => {
      console.error('login failed', err);
    });
  }
});