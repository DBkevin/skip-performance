# AI发型分析小程序（Go + MySQL 版）

本项目实现了一个采用 **Go 语言 + MySQL** 的 AI 发型分析推荐系统，提供 RESTful API，并配套实现了一个微信小程序前端。用户可上传照片生成个性化发型分析报告，查看 15 种发型建议，并通过分享邀请好友获得高清无水印海报。前端页面采用柔和渐变、卡片式布局和渐变按钮，整体风格简洁美观。

## 项目结构

```
hairstyle-go/
├── backend/                # Go 后端服务
│   ├── cmd/server/main.go  # 入口程序
│   ├── internal/           # 内部实现
│   │   ├── ai/             # AI 服务接口与模拟实现
│   │   ├── db/             # 数据库初始化
│   │   ├── models/         # 数据模型
│   │   ├── handlers/       # HTTP 请求处理
│   │   ├── auth/           # 简单的 token 生成与解析
│   │   ├── middleware/     # 中间件（如鉴权）
│   │   └── ai/             # AI 服务接口与模拟实现
│   ├── config.yaml         # 数据库等配置
│   ├── go.mod              # Go 依赖管理
│   └── go.sum
├── miniprogram/            # 微信小程序前端
│   ├── app.js
│   ├── app.json
│   ├── app.wxss
│   ├── pages/              # 小程序页面
│   │   ├── index/
│   │   ├── upload/
│   │   ├── wait/
│   │   ├── result/
│   │   └── my/
│   └── utils/
└── README.md               # 使用说明（本文件）
```

## 部署说明

### 前置条件

1. **安装 Go 语言**：推荐使用 Go 1.20 或更高版本。
2. **安装 MySQL**：推荐 MySQL 8.0 以上版本，并创建数据库。例如在本地创建数据库 `hairstyle`：

   ```sql
   CREATE DATABASE hairstyle DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
   ```

3. **配置后端**：在 `backend/config.yaml` 中配置 MySQL 连接信息。例如：

   ```yaml
   mysqlDSN: "user:password@tcp(127.0.0.1:3306)/hairstyle?charset=utf8mb4&parseTime=True&loc=Local"
   serverPort: ":8080"
   uploadDir: "./uploads"
   ```

### 启动后端服务

1. 进入 `backend` 目录，执行 `go mod tidy` 安装依赖。
2. 执行 `go run cmd/server/main.go` 启动 HTTP 服务。
3. 后端启动后监听在配置的 `serverPort`（默认 8080）。
4. **注意**：后端使用 GORM 自动迁移创建表，首次启动时会自动在数据库中创建所需表结构。
 5. 服务启动时会自动创建配置文件中指定的 `uploadDir`，并将其写入环境变量 `UPLOAD_DIR`，用于后端在删除报告时查找并删除原始图片。

### 启动小程序前端

1. 使用微信开发者工具导入 `miniprogram` 目录。
2. 根据实际后端地址修改 `miniprogram/app.js` 中的 `apiBaseUrl`（例如 `http://localhost:8080/api`）。
3. 运行小程序，即可体验功能。前端页面使用渐变背景、圆角卡片和主题色按钮，整体视觉更舒适，也支持分享到好友获得高清海报。您可以根据品牌风格进一步调整配色和排版。

### 使用流程

1. 打开小程序，点击“开始测试”进入上传界面。
2. 上传一张正面照片并开始分析，后端创建报告并模拟 AI 生成结果。
3. 等待处理完成后跳转到结果页，显示分析报告和海报。用户可保存带水印版，分享后解锁高清版。
4. 分享时会携带当前报告编号作为参数。当朋友通过分享链接进入小程序时，系统会记录一次“点击”；朋友完成发型分析后，系统会记录“完成”并为邀请人对应的报告解锁高清无水印版。
5. 在“我的”页面查看历史报告列表和状态，可进入查看结果或继续等待；也可以删除不需要的报告。

## 注意事项

* AI 处理逻辑通过 `internal/ai/mock_ai.go` 模拟，实际应用中需替换为真实模型或服务接口。
* 为了简单起见，本示例中用户登录通过传入 openid 并生成简单的 token，没有对接微信接口；上线前需接入微信授权登录流程。
* 项目采用 GORM 的 AutoMigrate 功能自动创建表；如果需要版本控制迁移，可引入 `golang-migrate` 等工具。
