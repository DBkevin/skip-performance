// app.js
App({
  globalData: {
    apiBaseUrl: 'http://localhost:8080/api', // 请根据部署修改
    token: '',
    userInfo: null
  },
  onLaunch() {
    // 自动登录：调用 wx.login 获取 code，发送到后端获取 token
    const that = this;
    wx.login({
      success(res) {
        if (res.code) {
          // 使用 code 作为 openid 发送到后端换取 token；实际使用时应调用云函数解密 openid
          wx.request({
            url: that.globalData.apiBaseUrl + '/wechat/login',
            method: 'POST',
            data: {
              openid: res.code,
              nickname: '',
              avatar: ''
            },
            success(response) {
              if (response.statusCode === 200) {
                that.globalData.token = response.data.token;
                that.globalData.userInfo = { id: response.data.user_id };
              }
            }
          });
        }
      }
    });
  }
});