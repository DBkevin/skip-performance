// utils/api.js
// 封装请求接口，统一处理 token

const request = (options) => {
  const app = getApp();
  const token = app.globalData.token;
  return new Promise((resolve, reject) => {
    wx.request({
      ...options,
      header: {
        ...(options.header || {}),
        Authorization: token ? `Bearer ${token}` : ''
      },
      success: (res) => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(res.data);
        } else {
          reject(res.data);
        }
      },
      fail: (err) => reject(err)
    });
  });
};

module.exports = {
  request,
  login(data) {
    return request({
      url: getApp().globalData.apiBaseUrl + '/wechat/login',
      method: 'POST',
      data
    });
  },
  createReport(filePath) {
    const app = getApp();
    const token = app.globalData.token;
    return new Promise((resolve, reject) => {
      wx.uploadFile({
        url: app.globalData.apiBaseUrl + '/reports',
        filePath,
        name: 'image',
        header: {
          Authorization: `Bearer ${token}`
        },
        success(res) {
          try {
            const data = JSON.parse(res.data);
            resolve(data);
          } catch (e) {
            reject(res);
          }
        },
        fail(err) {
          reject(err);
        }
      });
    });
  },
  getReport(id) {
    return request({
      url: `${getApp().globalData.apiBaseUrl}/reports/${id}`,
      method: 'GET'
    });
  },
  getStyles(id) {
    return request({
      url: `${getApp().globalData.apiBaseUrl}/reports/${id}/styles`,
      method: 'GET'
    });
  },
  saveWatermark(id) {
    return request({
      url: `${getApp().globalData.apiBaseUrl}/reports/${id}/save-watermark`,
      method: 'POST'
    });
  },
  unlockReport(id, method) {
    return request({
      url: `${getApp().globalData.apiBaseUrl}/reports/${id}/unlock`,
      method: 'POST',
      data: { method }
    });
  },
  listReports() {
    return request({
      url: `${getApp().globalData.apiBaseUrl}/reports`,
      method: 'GET'
    });
  },
  inviteClick(inviterReportId) {
    return request({
      url: `${getApp().globalData.apiBaseUrl}/invite/click`,
      method: 'POST',
      data: { inviter_report_id: inviterReportId }
    });
  },
  inviteComplete(inviterReportId) {
    return request({
      url: `${getApp().globalData.apiBaseUrl}/invite/complete`,
      method: 'POST',
      data: { inviter_report_id: inviterReportId }
    });
  },
  createLead(lead) {
    return request({
      url: `${getApp().globalData.apiBaseUrl}/leads`,
      method: 'POST',
      data: lead
    });
  }
};