// pages/result/result.js
const api = require('../../utils/api.js');

Page({
  data: {
    reportId: null,
    report: {},
    styles: {
      best: [],
      optional: [],
      avoid: []
    },
    posterUrl: ''
  },
  onLoad(options) {
    const { id } = options;
    this.setData({ reportId: id });
    this.fetchData();
  },
  fetchData() {
    api.getReport(this.data.reportId).then((res) => {
      const posterUrl = res.is_unlocked ? res.poster_clean_url : res.poster_watermarked_url;
      this.setData({ report: res, posterUrl });
    });
    api.getStyles(this.data.reportId).then((res) => {
      this.setData({ styles: res });
    });
  },
  savePoster() {
    // Save watermarked version
    const url = this.data.report.poster_watermarked_url;
    if (!url) {
      wx.showToast({ title: '海报未生成', icon: 'none' });
      return;
    }
    this.downloadAndSave(url);
  },
  saveCleanPoster() {
    const url = this.data.report.poster_clean_url;
    if (!url) {
      wx.showToast({ title: '高清版未生成', icon: 'none' });
      return;
    }
    this.downloadAndSave(url);
  },
  downloadAndSave(url) {
    wx.showLoading({ title: '下载中...' });
    wx.downloadFile({
      url: url,
      success: (res) => {
        const tempFilePath = res.tempFilePath;
        wx.saveImageToPhotosAlbum({
          filePath: tempFilePath,
          success: () => {
            wx.hideLoading();
            wx.showToast({ title: '已保存至相册', icon: 'success' });
          },
          fail: () => {
            wx.hideLoading();
            wx.showToast({ title: '保存失败', icon: 'none' });
          }
        });
      },
      fail: () => {
        wx.hideLoading();
        wx.showToast({ title: '下载失败', icon: 'none' });
      }
    });
  },
  unlockPoster() {
    // 显示提示引导用户分享，随后调用解锁接口
    wx.showModal({
      title: '分享解锁',
      content: '分享海报给好友完成测试后即可解锁高清版',
      confirmText: '去分享',
      success: (res) => {
        if (res.confirm) {
          // 调用分享
          wx.showShareMenu({ withShareTicket: true });
        }
      }
    });
  },
  onShareAppMessage() {
    const app = getApp();
    const inviterReportId = this.data.reportId;
    return {
      title: '快来体验AI发型分析',
      path: `/pages/index/index?inviter_report_id=${inviterReportId}`,
      imageUrl: this.data.posterUrl
    };
  }
});