// pages/my/my.js
const api = require('../../utils/api.js');

function mapStatus(status) {
  switch (status) {
    case 'pending':
      return '排队中';
    case 'analyzing':
      return '分析中';
    case 'generating':
      return '生成中';
    case 'completed':
      return '已完成';
    case 'failed':
      return '已失败';
    default:
      return status;
  }
}

Page({
  data: {
    reports: []
  },
  onShow() {
    this.loadReports();
  },
  loadReports() {
    api.listReports().then((list) => {
      // Add statusText property
      list.forEach(item => {
        item.statusText = mapStatus(item.status);
      });
      this.setData({ reports: list });
    }).catch((err) => {
      console.error(err);
    });
  },
  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    const status = e.currentTarget.dataset.status;
    if (status === 'completed') {
      wx.navigateTo({ url: `/pages/result/result?id=${id}` });
    } else if (status === 'failed') {
      wx.showToast({ title: '此报告已失败', icon: 'none' });
    } else {
      wx.navigateTo({ url: `/pages/wait/wait?id=${id}` });
    }
  },
  deleteReport(e) {
    const id = e.currentTarget.dataset.id;
    wx.showModal({
      title: '确认删除',
      content: '删除后无法恢复，确认删除该报告吗？',
      success: (res) => {
        if (res.confirm) {
          api.request({
            url: `${getApp().globalData.apiBaseUrl}/reports/${id}`,
            method: 'DELETE'
          }).then(() => {
            wx.showToast({ title: '已删除', icon: 'success' });
            this.loadReports();
          }).catch((err) => {
            wx.showToast({ title: '删除失败', icon: 'none' });
            console.error(err);
          });
        }
      }
    });
  }
});