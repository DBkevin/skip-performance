// pages/wait/wait.js
const api = require('../../utils/api.js');

Page({
  data: {
    reportId: null,
    statusText: '等待任务排队...',
    progress: 0,
    timer: null
  },
  onLoad(options) {
    const { id } = options;
    this.setData({ reportId: id });
    this.startPolling();
  },
  onUnload() {
    if (this.data.timer) {
      clearInterval(this.data.timer);
    }
  },
  startPolling() {
    const poll = () => {
      api.getReport(this.data.reportId).then((res) => {
        const status = res.status;
        let statusText = '';
        let progress = 0;
        switch (status) {
          case 'pending':
            statusText = '等待任务排队...';
            progress = 10;
            break;
          case 'analyzing':
            statusText = '正在分析照片...';
            progress = 40;
            break;
          case 'generating':
            statusText = '正在生成发型方案...';
            progress = 70;
            break;
          case 'completed':
            statusText = '分析完成';
            progress = 100;
            break;
          case 'failed':
            statusText = '生成失败，请稍后再试';
            progress = 100;
            break;
          default:
            statusText = status;
            progress = 0;
        }
        this.setData({ statusText, progress });
        if (status === 'completed') {
          clearInterval(this.data.timer);
          // 如果本地存在 inviter_report_id，说明当前用户是受邀用户，需要告知后端完成
          const inviterReportId = wx.getStorageSync('inviter_report_id');
          if (inviterReportId) {
            const api = require('../../utils/api.js');
            api.inviteComplete(inviterReportId).finally(() => {
              wx.removeStorageSync('inviter_report_id');
            });
          }
          setTimeout(() => {
            wx.redirectTo({ url: `/pages/result/result?id=${this.data.reportId}` });
          }, 500);
        } else if (status === 'failed') {
          clearInterval(this.data.timer);
          wx.showModal({
            title: '错误',
            content: '生成失败，请返回重新上传。',
            showCancel: false,
            success: () => {
              wx.navigateBack({});
            }
          });
        }
      }).catch((err) => {
        console.error(err);
      });
    };
    poll();
    const timer = setInterval(poll, 3000);
    this.setData({ timer });
  }
});