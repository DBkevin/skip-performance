// pages/index/index.js
Page({
  data: {},
  onLoad(options) {
    // 如果存在邀请参数，记录一次点击
    const inviterReportId = options.inviter_report_id;
    if (inviterReportId) {
      const api = require('../../utils/api.js');
      api.inviteClick(inviterReportId).catch((err) => {
        console.error('invite click error', err);
      });
      // 存储以便完成报告后回调 inviteComplete
      wx.setStorageSync('inviter_report_id', inviterReportId);
    }
  },
  startTest() {
    wx.navigateTo({
      url: '/pages/upload/upload'
    });
  }
});