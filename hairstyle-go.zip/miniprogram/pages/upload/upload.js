// pages/upload/upload.js
const api = require('../../utils/api.js');

Page({
  data: {
    image: '',
    checked: false
  },
  chooseImage() {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        this.setData({ image: res.tempFilePaths[0] });
      }
    });
  },
  onCheck(e) {
    this.setData({ checked: e.detail.value.length > 0 });
  },
  startAnalysis() {
    if (!this.data.image || !this.data.checked) return;
    wx.showLoading({ title: '正在上传...' });
    api.createReport(this.data.image).then((res) => {
      wx.hideLoading();
      const reportId = res.report_id;
      wx.navigateTo({
        url: `/pages/wait/wait?id=${reportId}`
      });
    }).catch((err) => {
      wx.hideLoading();
      wx.showToast({ title: '上传失败', icon: 'error' });
      console.error(err);
    });
  }
});