package db

import (
    "gorm.io/driver/mysql"
    "gorm.io/gorm"
)

// DB 是全局数据库连接实例。
var DB *gorm.DB

// Init 初始化 MySQL 连接。
func Init(dsn string) error {
    var err error
    DB, err = gorm.Open(mysql.Open(dsn), &gorm.Config{})
    return err
}