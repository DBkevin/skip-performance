package models

import (
    "time"
    "gorm.io/gorm"
)

// InviteRecord tracks the inviting relationship for unlocking clean posters.
// When a user invites another and they complete analysis, the inviter can unlock.
type InviteRecord struct {
    gorm.Model
    InviterUserID uint      `gorm:"column:inviter_user_id;index"`  // ID of the user who sent the invite
    InvitedUserID uint      `gorm:"column:invited_user_id;index"`  // ID of the user who accepted
    ReportID      uint      `gorm:"column:report_id;index"`        // ID of the report being unlocked
    Status        string    `gorm:"column:status;size:16"`          // clicked, completed
    CompletedAt   *time.Time `gorm:"column:completed_at"`            // when invite was completed
}

// TableName overrides table name.
func (InviteRecord) TableName() string {
    return "invite_records"
}