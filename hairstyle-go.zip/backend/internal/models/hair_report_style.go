package models

import "gorm.io/gorm"

// HairReportStyle represents one hairstyle recommendation entry.
// Category can be best, optional, or avoid.
// SortOrder defines ordering within a category.
type HairReportStyle struct {
    gorm.Model
    ReportID  uint   `gorm:"column:report_id;index"`          // reference to hair_reports.id
    Category  string `gorm:"column:category;size:16"`          // best, optional, avoid
    SortOrder int    `gorm:"column:sort_order"`                // ranking within category (1-5)
    StyleName string `gorm:"column:style_name;size:64"`        // hairstyle name
    Reason    string `gorm:"column:reason;type:text"`          // reason for recommendation
    ImageURL  string `gorm:"column:image_url;size:255"`        // avatar image url with hairstyle
}

// TableName overrides table name.
func (HairReportStyle) TableName() string {
    return "hair_report_styles"
}