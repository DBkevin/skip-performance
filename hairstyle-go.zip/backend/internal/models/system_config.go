package models

import "gorm.io/gorm"

// SystemConfig stores configurable key/value pairs for the system.
// It can be used for watermarks, share rules, etc.
type SystemConfig struct {
    gorm.Model
    Key   string `gorm:"column:key;size:64;uniqueIndex"`   // config key
    Value string `gorm:"column:value;type:text"`           // config value in JSON or plain
}

// TableName overrides table name.
func (SystemConfig) TableName() string {
    return "system_configs"
}