package models

import (
    "time"
    "gorm.io/gorm"
)

// HairReport represents a single hairstyle analysis report.
// It stores the uploaded image and generated results.
type HairReport struct {
    gorm.Model
    UserID               uint           `gorm:"column:user_id;index"`                       // reference to users.id
    OriginalImageURL     string         `gorm:"column:original_image_url;size:255"`          // path to uploaded image
    Status               string         `gorm:"column:status;size:32"`                       // pending, analyzing, generating, composing, completed, failed
    FaceShape            string         `gorm:"column:face_shape;size:32"`                   // e.g., round, square
    HairTexture          string         `gorm:"column:hair_texture;size:32"`                 // e.g., coarse, fine
    HairVolume           string         `gorm:"column:hair_volume;size:32"`                  // e.g., low, medium, high
    Temperament          string         `gorm:"column:temperament;size:32"`                  // e.g., elegant, sporty
    AnalysisJSON         string         `gorm:"column:analysis_json;type:text"`              // raw analysis JSON for reference
    PosterWatermarkedURL string         `gorm:"column:poster_watermarked_url;size:255"`      // watermarked poster URL
    PosterCleanURL       string         `gorm:"column:poster_clean_url;size:255"`            // clean poster URL
    IsUnlocked           bool           `gorm:"column:is_unlocked"`                          // whether the clean poster is unlocked
    UnlockMethod         string         `gorm:"column:unlock_method;size:16"`               // none, invite, paid, admin
    ErrorMessage         string         `gorm:"column:error_message;size:255"`               // error message if failed
    CompletedAt          *time.Time     `gorm:"column:completed_at"`                        // time when analysis completed
    User                 User           `gorm:"foreignKey:UserID"`                           // association to user
    Styles               []HairReportStyle `gorm:"foreignKey:ReportID"`                    // associated hairstyle proposals
}

// TableName overrides table name.
func (HairReport) TableName() string {
    return "hair_reports"
}