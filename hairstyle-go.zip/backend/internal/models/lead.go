package models

import "gorm.io/gorm"

// Lead represents a sales lead or consultation request from a user.
// It may contain contact information so staff can follow up.
type Lead struct {
    gorm.Model
    UserID    uint   `gorm:"column:user_id;index"`                // reference to users.id
    ReportID  uint   `gorm:"column:report_id;index"`              // reference to hair_reports.id
    Name      string `gorm:"column:name;size:64"`                  // optional name
    Phone     string `gorm:"column:phone;size:32"`                 // phone number
    WeChat    string `gorm:"column:wechat;size:64"`                // WeChat ID
    Source    string `gorm:"column:source;size:32"`                // where the lead came from (page or event)
    Remark    string `gorm:"column:remark;type:text"`              // optional remark
}

// TableName overrides table name.
func (Lead) TableName() string {
    return "leads"
}