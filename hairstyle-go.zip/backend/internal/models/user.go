package models

import "gorm.io/gorm"

// User represents a WeChat user.
// We keep basic profile information and optional phone.
// The OpenID field should be unique per mini program.
type User struct {
    gorm.Model
    OpenID   string `gorm:"column:openid;uniqueIndex;size:64"`  // unique identifier from WeChat
    Nickname string `gorm:"column:nickname;size:64"`             // user's nickname
    Avatar   string `gorm:"column:avatar;size:255"`              // avatar URL
    Phone    string `gorm:"column:phone;size:32"`                // optional phone number
}

// TableName overrides the default table name.
func (User) TableName() string {
    return "users"
}