package middleware

import (
    "net/http"
    "strings"

    "github.com/gin-gonic/gin"
    "hairstyle-go/backend/internal/auth"
    "hairstyle-go/backend/internal/models"
    "hairstyle-go/backend/internal/db"
)

// AuthMiddleware is a Gin middleware that checks for a Bearer token and sets
// the current user in the context. It looks up the user in the database using
// the parsed user ID. If the token is missing or invalid, it aborts with 401.
func AuthMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        authHeader := c.GetHeader("Authorization")
        if authHeader == "" {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "missing authorization header"})
            return
        }
        // Expect header in form "Bearer token"
        parts := strings.SplitN(authHeader, " ", 2)
        if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid authorization header"})
            return
        }
        userID, err := auth.ParseToken(parts[1])
        if err != nil || userID == 0 {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid token"})
            return
        }
        var user models.User
        if result := db.DB.First(&user, userID); result.Error != nil {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "user not found"})
            return
        }
        // Save user to context
        c.Set("currentUser", &user)
        c.Next()
    }
}