package auth

import (
    "errors"
    "strconv"
)

// GenerateToken generates a simple token string from a user ID.
// In this MVP we use the numeric user ID as the token value.
func GenerateToken(userID uint) string {
    return strconv.FormatUint(uint64(userID), 10)
}

// ParseToken parses the token and returns the user ID.
// If the token is invalid or not an integer, an error is returned.
func ParseToken(token string) (uint, error) {
    if token == "" {
        return 0, errors.New("empty token")
    }
    id, err := strconv.ParseUint(token, 10, 64)
    if err != nil {
        return 0, errors.New("invalid token")
    }
    return uint(id), nil
}