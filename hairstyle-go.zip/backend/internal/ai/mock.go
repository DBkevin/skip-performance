package ai

import (
    "fmt"
)

// MockProvider is a mock implementation of the Provider interface.
// It returns deterministic values suitable for development and testing.
type MockProvider struct{}

// AnalyzeImage returns fake analysis data.
func (m MockProvider) AnalyzeImage(imagePath string) (map[string]interface{}, error) {
    return map[string]interface{}{
        "face_shape":   "圆脸",
        "hair_texture": "自然直",
        "hair_volume":  "中",
        "temperament":  "亲和",
        "strategy": map[string][]string{
            "enhance": {"顶部高度", "层次感"},
            "avoid":   {"厚重齐刘海"},
        },
    }, nil
}

// GenerateStyles returns fixed hairstyles for each category.
func (m MockProvider) GenerateStyles(analysis map[string]interface{}) (map[string][]map[string]string, error) {
    styles := map[string][]map[string]string{
        "best":    {},
        "optional": {},
        "avoid":   {},
    }
    for i := 1; i <= 5; i++ {
        styles["best"] = append(styles["best"], map[string]string{
            "name":   fmt.Sprintf("最佳方案%d", i),
            "reason": fmt.Sprintf("根据分析结果推荐的最佳方案%d", i),
        })
        styles["optional"] = append(styles["optional"], map[string]string{
            "name":   fmt.Sprintf("可尝试方案%d", i),
            "reason": fmt.Sprintf("根据分析结果推荐的可尝试方案%d", i),
        })
        styles["avoid"] = append(styles["avoid"], map[string]string{
            "name":   fmt.Sprintf("不建议方案%d", i),
            "reason": fmt.Sprintf("根据分析结果不建议的方案%d", i),
        })
    }
    return styles, nil
}

// GenerateStyleImages returns placeholder image URLs for each style.
func (m MockProvider) GenerateStyleImages(styles map[string][]map[string]string, imagePath string) (map[string][]string, error) {
    images := map[string][]string{}
    for cat, list := range styles {
        images[cat] = []string{}
        for i := range list {
            // Use placeholder.com to generate simple image with text
            images[cat] = append(images[cat], fmt.Sprintf("https://via.placeholder.com/150?text=%s%d", cat, i+1))
        }
    }
    return images, nil
}

// ComposePoster returns a placeholder poster URL.
func (m MockProvider) ComposePoster(analysis map[string]interface{}, styles map[string][]map[string]string, styleImages map[string][]string, originalImagePath string, watermark bool) (string, error) {
    if watermark {
        return "https://via.placeholder.com/750x1000?text=Watermarked+Poster", nil
    }
    return "https://via.placeholder.com/750x1000?text=Poster", nil
}