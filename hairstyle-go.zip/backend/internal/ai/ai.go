package ai

import "hairstyle-go/backend/internal/models"

// Provider defines the interface required for AI operations.
// Real implementations can call external services to analyze images,
// generate hairstyle options, and compose posters. For the MVP, a mock
// implementation will be provided that returns deterministic data.
type Provider interface {
    // AnalyzeImage should inspect the given image and return analysis results.
    // imagePath is the absolute path to the uploaded image.
    AnalyzeImage(imagePath string) (map[string]interface{}, error)

    // GenerateStyles takes the analysis and produces 15 hairstyle suggestions.
    // The returned map contains three categories: best, optional, avoid.
    GenerateStyles(analysis map[string]interface{}) (map[string][]map[string]string, error)

    // GenerateStyleImages takes the styles and original image path, and returns
    // URLs to avatar images with each hairstyle applied. This is optional in the
    // MVP; you can return placeholder images.
    GenerateStyleImages(styles map[string][]map[string]string, imagePath string) (map[string][]string, error)

    // ComposePoster creates a final poster image from analysis, styles, and style images.
    // When watermark is true, a watermark should be added to the poster.
    ComposePoster(analysis map[string]interface{}, styles map[string][]map[string]string, styleImages map[string][]string, originalImagePath string, watermark bool) (string, error)
}