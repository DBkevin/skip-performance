package handlers

import (
    "encoding/json"
    "fmt"
    "io"
    "net/http"
    "os"
    "path/filepath"
    "time"

    "github.com/gin-gonic/gin"
    "github.com/google/uuid"
    "hairstyle-go/backend/internal/ai"
    "hairstyle-go/backend/internal/db"
    "hairstyle-go/backend/internal/models"
)

// LoginHandler handles a simple login via openid.
// It expects a JSON body with an "openid" field and optional nickname and avatar.
// If the user exists, it returns a token for that user; otherwise, it creates a new user.
func LoginHandler(c *gin.Context) {
    var req struct {
        OpenID   string `json:"openid"`
        Nickname string `json:"nickname"`
        Avatar   string `json:"avatar"`
    }
    if err := c.ShouldBindJSON(&req); err != nil || req.OpenID == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid openid"})
        return
    }
    // Check if user exists
    var user models.User
    result := db.DB.Where("openid = ?", req.OpenID).First(&user)
    if result.Error != nil {
        // Create new user
        user = models.User{
            OpenID:   req.OpenID,
            Nickname: req.Nickname,
            Avatar:   req.Avatar,
        }
        if err := db.DB.Create(&user).Error; err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to create user"})
            return
        }
    } else {
        // Optionally update nickname and avatar
        updated := false
        if req.Nickname != "" && req.Nickname != user.Nickname {
            user.Nickname = req.Nickname
            updated = true
        }
        if req.Avatar != "" && req.Avatar != user.Avatar {
            user.Avatar = req.Avatar
            updated = true
        }
        if updated {
            db.DB.Save(&user)
        }
    }
    // Generate token
    token := fmt.Sprintf("%d", user.ID)
    c.JSON(http.StatusOK, gin.H{"token": token, "user_id": user.ID})
}

// processReport performs the AI analysis on a report asynchronously.
func processReport(reportID uint, provider ai.Provider, uploadDir string) {
    // Run in goroutine so that HTTP handler returns immediately
    go func() {
        // Use a new DB session to avoid issues with concurrent goroutines
        var report models.HairReport
        if err := db.DB.First(&report, reportID).Error; err != nil {
            return
        }
        // Update status to analyzing
        report.Status = "analyzing"
        db.DB.Save(&report)

        // Perform analysis
        analysis, err := provider.AnalyzeImage(filepath.Join(uploadDir, filepath.Base(report.OriginalImageURL)))
        if err != nil {
            report.Status = "failed"
            report.ErrorMessage = err.Error()
            db.DB.Save(&report)
            return
        }
        // Serialize analysis JSON
        analysisBytes, _ := json.Marshal(analysis)
        // Update report fields
        report.Status = "generating"
        report.FaceShape = getStringFromMap(analysis, "face_shape")
        report.HairTexture = getStringFromMap(analysis, "hair_texture")
        report.HairVolume = getStringFromMap(analysis, "hair_volume")
        report.Temperament = getStringFromMap(analysis, "temperament")
        report.AnalysisJSON = string(analysisBytes)
        db.DB.Save(&report)
        // Generate styles
        styles, err := provider.GenerateStyles(analysis)
        if err != nil {
            report.Status = "failed"
            report.ErrorMessage = err.Error()
            db.DB.Save(&report)
            return
        }
        // Generate style images
        images, err := provider.GenerateStyleImages(styles, filepath.Join(uploadDir, filepath.Base(report.OriginalImageURL)))
        if err != nil {
            report.Status = "failed"
            report.ErrorMessage = err.Error()
            db.DB.Save(&report)
            return
        }
        // Save styles to DB
        for category, items := range styles {
            for idx, item := range items {
                style := models.HairReportStyle{
                    ReportID:  report.ID,
                    Category:  category,
                    SortOrder: idx + 1,
                    StyleName: item["name"],
                    Reason:    item["reason"],
                    ImageURL:  images[category][idx],
                }
                db.DB.Create(&style)
            }
        }
        // Compose posters
        posterWater, err := provider.ComposePoster(analysis, styles, images, filepath.Join(uploadDir, filepath.Base(report.OriginalImageURL)), true)
        if err != nil {
            report.Status = "failed"
            report.ErrorMessage = err.Error()
            db.DB.Save(&report)
            return
        }
        posterClean, err := provider.ComposePoster(analysis, styles, images, filepath.Join(uploadDir, filepath.Base(report.OriginalImageURL)), false)
        if err != nil {
            report.Status = "failed"
            report.ErrorMessage = err.Error()
            db.DB.Save(&report)
            return
        }
        // Complete report
        now := time.Now()
        report.Status = "completed"
        report.PosterWatermarkedURL = posterWater
        report.PosterCleanURL = posterClean
        report.CompletedAt = &now
        db.DB.Save(&report)
    }()
}

// helper to get string from map
func getStringFromMap(m map[string]interface{}, key string) string {
    if v, ok := m[key]; ok {
        if s, ok2 := v.(string); ok2 {
            return s
        }
    }
    return ""
}

// CreateReportHandler returns a handler for POST /reports.
// It expects a file uploaded with field name "image" and creates a HairReport.
func CreateReportHandler(uploadDir string, provider ai.Provider) gin.HandlerFunc {
    return func(c *gin.Context) {
        // Retrieve current user
        userObj, exists := c.Get("currentUser")
        if !exists {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
            return
        }
        user := userObj.(*models.User)
        // Parse uploaded image
        file, header, err := c.Request.FormFile("image")
        if err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "no image uploaded"})
            return
        }
        defer file.Close()
        // Generate unique filename
        filename := uuid.New().String() + filepath.Ext(header.Filename)
        // Save file to upload directory
        dstPath := filepath.Join(uploadDir, filename)
        out, err := os.Create(dstPath)
        if err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to save image"})
            return
        }
        defer out.Close()
        if _, err := io.Copy(out, file); err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to save image"})
            return
        }
        // Create report record
        report := models.HairReport{
            UserID:           user.ID,
            OriginalImageURL: filename,
            Status:           "pending",
            IsUnlocked:       false,
            UnlockMethod:     "none",
        }
        if err := db.DB.Create(&report).Error; err != nil {
            c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to create report"})
            return
        }
        // Start background processing
        processReport(report.ID, provider, uploadDir)
        // Respond with report ID
        c.JSON(http.StatusOK, gin.H{"report_id": report.ID})
    }
}

// GetReportHandler handles GET /reports/:id to return report details.
func GetReportHandler(c *gin.Context) {
        // Retrieve current user
        userObj, exists := c.Get("currentUser")
        if !exists {
            c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
            return
        }
        user := userObj.(*models.User)
        // Parse report ID
        var report models.HairReport
        if err := db.DB.Preload("Styles").First(&report, c.Param("id")).Error; err != nil {
            c.JSON(http.StatusNotFound, gin.H{"error": "report not found"})
            return
        }
        // Ensure user owns the report
        if report.UserID != user.ID {
            c.JSON(http.StatusForbidden, gin.H{"error": "forbidden"})
            return
        }
        // Assemble response
        // parse analysis JSON into struct if necessary; for simplicity, send as string
        c.JSON(http.StatusOK, gin.H{
            "id":                     report.ID,
            "status":                 report.Status,
            "face_shape":             report.FaceShape,
            "hair_texture":           report.HairTexture,
            "hair_volume":            report.HairVolume,
            "temperament":            report.Temperament,
            "analysis_json":          report.AnalysisJSON,
            "poster_watermarked_url": report.PosterWatermarkedURL,
            "poster_clean_url":       report.PosterCleanURL,
            "is_unlocked":            report.IsUnlocked,
            "unlock_method":          report.UnlockMethod,
            "completed_at":           report.CompletedAt,
        })
}

// ListReportsHandler handles GET /reports to return all reports for the current user.
func ListReportsHandler(c *gin.Context) {
    userObj, exists := c.Get("currentUser")
    if !exists {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }
    user := userObj.(*models.User)
    var reports []models.HairReport
    if err := db.DB.Where("user_id = ?", user.ID).Order("created_at desc").Find(&reports).Error; err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch reports"})
        return
    }
    // Build simple list
    list := make([]gin.H, 0, len(reports))
    for _, r := range reports {
        list = append(list, gin.H{
            "id":         r.ID,
            "status":     r.Status,
            "created_at": r.CreatedAt,
            "is_unlocked": r.IsUnlocked,
        })
    }
    c.JSON(http.StatusOK, list)
}

// GetReportStylesHandler handles GET /reports/:id/styles to return styles grouped by category.
func GetReportStylesHandler(c *gin.Context) {
    // Retrieve current user
    userObj, exists := c.Get("currentUser")
    if !exists {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }
    user := userObj.(*models.User)
    // Find report
    var report models.HairReport
    if err := db.DB.First(&report, c.Param("id")).Error; err != nil {
        c.JSON(http.StatusNotFound, gin.H{"error": "report not found"})
        return
    }
    if report.UserID != user.ID {
        c.JSON(http.StatusForbidden, gin.H{"error": "forbidden"})
        return
    }
    // Retrieve styles
    var styles []models.HairReportStyle
    if err := db.DB.Where("report_id = ?", report.ID).Order("category, sort_order").Find(&styles).Error; err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch styles"})
        return
    }
    // Group by category
    response := map[string][]gin.H{
        "best":    {},
        "optional": {},
        "avoid":   {},
    }
    for _, s := range styles {
        item := gin.H{
            "name":       s.StyleName,
            "reason":     s.Reason,
            "image_url":  s.ImageURL,
            "sort_order": s.SortOrder,
        }
        response[s.Category] = append(response[s.Category], item)
    }
    c.JSON(http.StatusOK, response)
}

// SaveWatermarkHandler handles POST /reports/:id/save-watermark.
// Since the poster is already generated in background, simply returns the watermarked URL.
func SaveWatermarkHandler(c *gin.Context) {
    userObj, exists := c.Get("currentUser")
    if !exists {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }
    user := userObj.(*models.User)
    var report models.HairReport
    if err := db.DB.First(&report, c.Param("id")).Error; err != nil {
        c.JSON(http.StatusNotFound, gin.H{"error": "report not found"})
        return
    }
    if report.UserID != user.ID {
        c.JSON(http.StatusForbidden, gin.H{"error": "forbidden"})
        return
    }
    // In a real system, you might trigger saving to album here; we just return URL
    c.JSON(http.StatusOK, gin.H{"poster_watermarked_url": report.PosterWatermarkedURL})
}

// UnlockReportHandler handles POST /reports/:id/unlock.
// It expects a JSON body with field "method" (invite, paid, admin).
func UnlockReportHandler(c *gin.Context) {
    userObj, exists := c.Get("currentUser")
    if !exists {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }
    user := userObj.(*models.User)
    var report models.HairReport
    if err := db.DB.First(&report, c.Param("id")).Error; err != nil {
        c.JSON(http.StatusNotFound, gin.H{"error": "report not found"})
        return
    }
    if report.UserID != user.ID {
        c.JSON(http.StatusForbidden, gin.H{"error": "forbidden"})
        return
    }
    var req struct {
        Method string `json:"method"`
    }
    if err := c.ShouldBindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid method"})
        return
    }
    switch req.Method {
    case "invite", "paid", "admin":
        report.IsUnlocked = true
        report.UnlockMethod = req.Method
        db.DB.Save(&report)
        c.JSON(http.StatusOK, gin.H{"poster_clean_url": report.PosterCleanURL})
    default:
        c.JSON(http.StatusBadRequest, gin.H{"error": "unsupported unlock method"})
    }
}

// DeleteReportHandler handles DELETE /reports/:id to remove a report.
// It deletes the report and associated styles; optionally removes the uploaded image.
func DeleteReportHandler(c *gin.Context) {
    userObj, exists := c.Get("currentUser")
    if !exists {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }
    user := userObj.(*models.User)
    var report models.HairReport
    if err := db.DB.First(&report, c.Param("id")).Error; err != nil {
        c.JSON(http.StatusNotFound, gin.H{"error": "report not found"})
        return
    }
    if report.UserID != user.ID {
        c.JSON(http.StatusForbidden, gin.H{"error": "forbidden"})
        return
    }
    // Delete styles
    db.DB.Where("report_id = ?", report.ID).Delete(&models.HairReportStyle{})
    // Delete invite records referencing this report
    db.DB.Where("report_id = ?", report.ID).Delete(&models.InviteRecord{})
    // Delete leads referencing this report
    db.DB.Where("report_id = ?", report.ID).Delete(&models.Lead{})
    // Remove image file
    uploadDir := os.Getenv("UPLOAD_DIR")
    if uploadDir != "" && report.OriginalImageURL != "" {
        _ = os.Remove(filepath.Join(uploadDir, filepath.Base(report.OriginalImageURL)))
    }
    // Delete report
    db.DB.Delete(&report)
    c.JSON(http.StatusOK, gin.H{"message": "deleted"})
}

// InviteClickHandler handles POST /invite/click.
// It expects JSON with "inviter_report_id" to track who shared the report.
// If the invited user clicks the share link, we create an invite record.
func InviteClickHandler(c *gin.Context) {
    userObj, exists := c.Get("currentUser")
    if !exists {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }
    invited := userObj.(*models.User)
    var req struct {
        InviterReportID uint `json:"inviter_report_id"`
    }
    if err := c.ShouldBindJSON(&req); err != nil || req.InviterReportID == 0 {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid request"})
        return
    }
    // Find inviter's report
    var report models.HairReport
    if err := db.DB.First(&report, req.InviterReportID).Error; err != nil {
        c.JSON(http.StatusNotFound, gin.H{"error": "report not found"})
        return
    }
    // Create invite record with status clicked
    record := models.InviteRecord{
        InviterUserID: report.UserID,
        InvitedUserID: invited.ID,
        ReportID:      report.ID,
        Status:        "clicked",
    }
    db.DB.Create(&record)
    c.JSON(http.StatusOK, gin.H{"message": "click recorded"})
}

// InviteCompleteHandler handles POST /invite/complete.
// It expects JSON with "inviter_report_id" to indicate which report is being unlocked.
// When the invited user completes a report, we mark the invite record as completed and unlock.
func InviteCompleteHandler(c *gin.Context) {
    userObj, exists := c.Get("currentUser")
    if !exists {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }
    invited := userObj.(*models.User)
    var req struct {
        InviterReportID uint `json:"inviter_report_id"`
    }
    if err := c.ShouldBindJSON(&req); err != nil || req.InviterReportID == 0 {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid request"})
        return
    }
    // Find the invite record for this invited user and report
    var record models.InviteRecord
    if err := db.DB.Where("report_id = ? AND invited_user_id = ?", req.InviterReportID, invited.ID).First(&record).Error; err != nil {
        c.JSON(http.StatusNotFound, gin.H{"error": "invite record not found"})
        return
    }
    // Update status to completed
    now := time.Now()
    record.Status = "completed"
    record.CompletedAt = &now
    db.DB.Save(&record)
    // Unlock the inviter's report
    var report models.HairReport
    if err := db.DB.First(&report, req.InviterReportID).Error; err == nil {
        report.IsUnlocked = true
        report.UnlockMethod = "invite"
        db.DB.Save(&report)
    }
    c.JSON(http.StatusOK, gin.H{"message": "invite completed"})
}

// CreateLeadHandler handles POST /leads to submit a sales lead.
// It expects JSON with fields: report_id (optional), name, phone, wechat, source, remark.
func CreateLeadHandler(c *gin.Context) {
    userObj, exists := c.Get("currentUser")
    if !exists {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "unauthorized"})
        return
    }
    user := userObj.(*models.User)
    var req struct {
        ReportID uint   `json:"report_id"`
        Name     string `json:"name"`
        Phone    string `json:"phone"`
        WeChat   string `json:"wechat"`
        Source   string `json:"source"`
        Remark   string `json:"remark"`
    }
    if err := c.ShouldBindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid request"})
        return
    }
    lead := models.Lead{
        UserID:   user.ID,
        ReportID: req.ReportID,
        Name:     req.Name,
        Phone:    req.Phone,
        WeChat:   req.WeChat,
        Source:   req.Source,
        Remark:   req.Remark,
    }
    if err := db.DB.Create(&lead).Error; err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to create lead"})
        return
    }
    c.JSON(http.StatusOK, gin.H{"message": "lead submitted"})
}