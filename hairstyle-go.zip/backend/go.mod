module hairstyle-go/backend

go 1.20

require (
    github.com/gin-gonic/gin v1.9.1
    github.com/google/uuid v1.3.1
    gorm.io/driver/mysql v1.5.0
    gorm.io/gorm v1.23.8
    gopkg.in/yaml.v3 v3.0.1
)