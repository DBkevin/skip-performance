package main

import (
    "fmt"
    "io/ioutil"
    "log"
    "net/http"
    "os"
    "path/filepath"

    "github.com/gin-contrib/cors"
    "github.com/gin-gonic/gin"
    "gopkg.in/yaml.v3"

    "hairstyle-go/backend/internal/ai"
    "hairstyle-go/backend/internal/auth"
    "hairstyle-go/backend/internal/db"
    "hairstyle-go/backend/internal/handlers"
    "hairstyle-go/backend/internal/middleware"
    "hairstyle-go/backend/internal/models"
)

// Config holds configuration values loaded from config.yaml.
type Config struct {
    MysqlDSN  string `yaml:"mysqlDSN"`
    ServerPort string `yaml:"serverPort"`
    UploadDir  string `yaml:"uploadDir"`
}

func loadConfig(configPath string) (*Config, error) {
    data, err := ioutil.ReadFile(configPath)
    if err != nil {
        return nil, err
    }
    var cfg Config
    if err := yaml.Unmarshal(data, &cfg); err != nil {
        return nil, err
    }
    return &cfg, nil
}

func main() {
    // Determine config path relative to working directory
    cfgPath := "config.yaml"
    if envPath := os.Getenv("CONFIG_PATH"); envPath != "" {
        cfgPath = envPath
    }
    cfg, err := loadConfig(cfgPath)
    if err != nil {
        log.Fatalf("failed to load config: %v", err)
    }

    // Initialize database
    if err := db.Init(cfg.MysqlDSN); err != nil {
        log.Fatalf("failed to connect to database: %v", err)
    }

    // Auto-migrate models
    if err := db.DB.AutoMigrate(&models.User{}, &models.HairReport{}, &models.HairReportStyle{}, &models.InviteRecord{}, &models.Lead{}, &models.SystemConfig{}); err != nil {
        log.Fatalf("failed to migrate database: %v", err)
    }

    // Create upload directory if it doesn't exist
    if err := os.MkdirAll(cfg.UploadDir, os.ModePerm); err != nil {
        log.Fatalf("failed to create upload directory: %v", err)
    }

    // Export upload directory in environment so handlers can access it when deleting files.
    os.Setenv("UPLOAD_DIR", cfg.UploadDir)

    // Initialize AI provider (mock)
    var provider ai.Provider = ai.MockProvider{}

    // Create Gin router
    router := gin.Default()
    // Enable CORS for development; you may restrict in production
    router.Use(cors.Default())

    // Attach upload directory and provider to handlers via closure
    api := router.Group("/api")
    {
        api.POST("/wechat/login", handlers.LoginHandler)

        authorized := api.Group("")
        authorized.Use(middleware.AuthMiddleware())
        {
            authorized.POST("/reports", handlers.CreateReportHandler(cfg.UploadDir, provider))
            authorized.GET("/reports", handlers.ListReportsHandler)
            authorized.GET("/reports/:id", handlers.GetReportHandler)
            authorized.GET("/reports/:id/styles", handlers.GetReportStylesHandler)
            authorized.POST("/reports/:id/save-watermark", handlers.SaveWatermarkHandler)
            authorized.POST("/reports/:id/unlock", handlers.UnlockReportHandler)
            authorized.DELETE("/reports/:id", handlers.DeleteReportHandler)
            authorized.POST("/invite/click", handlers.InviteClickHandler)
            authorized.POST("/invite/complete", handlers.InviteCompleteHandler)
            authorized.POST("/leads", handlers.CreateLeadHandler)
        }
    }

    // Start server
    addr := ":" + cfg.ServerPort
    if cfg.ServerPort == "" {
        addr = ":8080"
    }
    log.Printf("Starting server on %s...", addr)
    if err := router.Run(addr); err != nil {
        log.Fatalf("failed to run server: %v", err)
    }
}